import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:arman_vpn/core/core_api.dart';

void main() {
  group('CoreApi', () {
    late HttpServer server;
    late CoreApi api;
    final seen = <String, Object?>{};
    Completer<void>? relayFinish;

    setUp(() async {
      seen.clear();
      relayFinish = null;
      // A local fixture: unknown requests fail and nothing leaves loopback.
      server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      server.listen((req) async {
        if (req.method == 'GET' && req.uri.path == '/api/backup') {
          seen['token'] = req.headers.value('X-Local-Token');
          req.response
            ..headers.contentType = ContentType('application', 'zip')
            ..headers.set(
              'Content-Disposition',
              'attachment; filename="Arman-VPN-backup-2026-11-06_19-26-03.zip"',
            )
            ..add([0x50, 0x4b, 0x03, 0x04]);
          await req.response.close();
          return;
        }
        final body = await utf8.decoder.bind(req).join();
        seen['token'] = req.headers.value('X-Local-Token');
        seen['type'] = req.headers.contentType?.mimeType;
        seen['body'] = body;
        if (req.method == 'POST' && req.uri.path == '/api/relay/test') {
          try {
            req.response.bufferOutput = false;
            if (seen['rejectRelay'] == true) {
              req.response.statusCode = 500;
              req.response.write(
                '{"error":"fixture-secret must not be echoed"}',
              );
            } else {
              req.response.headers.contentType = ContentType(
                'application',
                'x-ndjson',
              );
              req.response.write(
                '${jsonEncode({
                  'type': 'step',
                  'step': {'stage': 'tcp', 'status': 'ok', 'detail': 'Connected', 'elapsed_ms': 12},
                })}\n',
              );
              await req.response.flush();
              if (relayFinish != null) await relayFinish!.future;
              req.response.write(
                '${jsonEncode({
                  'type': 'result',
                  'result': {
                    'ok': true,
                    'host': 'relay.example',
                    'total_ms': 20,
                    'steps': [
                      {'stage': 'tcp', 'status': 'ok', 'detail': 'Connected', 'elapsed_ms': 12},
                    ],
                  },
                })}\n',
              );
            }
            await req.response.close();
          } on HttpException {
            // Closing the dialog intentionally aborts this connection.
          } on SocketException {
            // The separate status client must remain available.
          }
          return;
        }
        // As the core's guard: a state change must be JSON.
        final json = req.headers.contentType?.mimeType == 'application/json';
        final (status, out) = switch ((req.method, req.uri.path)) {
          (final m, _) when m != 'GET' && !json => (
            415,
            {'error': 'requests must be JSON'},
          ),
          ('GET', '/api/status') => (
            200,
            {
              'state': {'phase': 'running', 'message': 'ok'},
              'system_proxy': 'set',
              'accounts': {'total': 2, 'ready': 1},
            },
          ),
          ('POST', '/api/system-proxy') => (200, {'mode': 'clear'}),
          ('POST', '/api/update/download') => (200, {'state': 'downloading'}),
          ('DELETE', '/api/accounts/a') => (200, {}),
          ('DELETE', '/api/signin/s') => (200, {}),
          ('POST', '/api/signin/browser/proxy') => (
            200,
            {'address': '127.0.0.1:41234'},
          ),
          ('DELETE', '/api/signin/browser/proxy') => (200, {'closed': true}),
          ('POST', '/api/backup/inspect') => (
            200,
            {
              'accounts': [
                {'email': 'a@example.com', 'has_password': true},
                {'email': 'b@example.com', 'exists': true},
              ],
            },
          ),
          ('POST', '/api/backup/import') => (200, {'added': 1, 'updated': 1}),
          ('POST', '/api/test') => (409, {'error': 'the proxy is not running'}),
          _ => (404, {'error': 'not found'}),
        };
        req.response
          ..statusCode = status
          ..headers.contentType = ContentType.json
          ..write(jsonEncode(out));
        await req.response.close();
      });
      api = CoreApi(
        CoreEndpoint(
          Uri.parse('http://127.0.0.1:${server.port}'),
          'secret-token',
        ),
      );
    });

    tearDown(() async {
      if (relayFinish != null && !relayFinish!.isCompleted) {
        relayFinish!.complete();
      }
      api.close();
      await server.close(force: true);
    });

    test('sends the local token and parses the status', () async {
      final s = await api.status();
      expect(seen['token'], 'secret-token');
      expect(s.systemProxySet, isTrue);
      expect(s.readyAccounts, 1);
      expect(s.totalAccounts, 2);
    });

    test('streams relay diagnostic steps and the final report', () async {
      final events = await api
          .testRelay('https://relay.example/?secret=fixture-secret')
          .toList();
      expect(events.length, 2);
      expect(events.first.step?.stage, 'tcp');
      expect(events.last.result?.ok, isTrue);
      expect(events.last.result?.steps.single.detail, 'Connected');
      expect(seen['token'], 'secret-token');
      expect(jsonDecode(seen['body'] as String), {
        'url': 'https://relay.example/?secret=fixture-secret',
        'stream': true,
      });
    });

    test(
      'cancelling relay diagnostics leaves status polling available',
      () async {
        relayFinish = Completer<void>();
        final first = await api
            .testRelay('https://relay.example/')
            .first
            .timeout(const Duration(seconds: 3));
        expect(first.step?.stage, 'tcp');
        expect((await api.status()).readyAccounts, 1);
        relayFinish!.complete();
      },
    );

    test('relay diagnostic API errors do not echo an input secret', () async {
      seen['rejectRelay'] = true;
      await expectLater(
        api.testRelay('https://relay.example/?secret=fixture-secret').toList(),
        throwsA(
          isA<CoreApiException>()
              .having((e) => e.statusCode, 'status', 500)
              .having(
                (e) => e.message,
                'message',
                isNot(contains('fixture-secret')),
              ),
        ),
      );
    });

    test('sends JSON with a DELETE too, which the core requires', () async {
      await api.removeAccount('a');
      expect(seen['type'], 'application/json');
      await api.cancelSignIn('s');
      expect(seen['type'], 'application/json');
    });

    test('saves and takes in a backup', () async {
      final file = await api.exportBackup();
      expect(seen['token'], 'secret-token');
      expect(file.name, 'Arman-VPN-backup-2026-11-06_19-26-03.zip');
      expect(file.bytes, [0x50, 0x4b, 0x03, 0x04]);

      final contents = await api.inspectBackup(file.bytes);
      expect(jsonDecode(seen['body'] as String), {
        'data': base64Encode(file.bytes),
      });
      expect(contents.accounts.map((a) => a.email), [
        'a@example.com',
        'b@example.com',
      ]);
      expect(contents.accounts.first.hasPassword, isTrue);
      expect(contents.accounts.last.exists, isTrue);

      final done = await api.importBackup(file.bytes);
      expect(seen['type'], 'application/json');
      expect(done.added + done.updated, 2);
    });

    test('opens and closes the sign-in proxy', () async {
      expect(await api.openSignInProxy(port: 41234), '127.0.0.1:41234');
      expect(jsonDecode(seen['body'] as String), {'port': 41234});
      await api.closeSignInProxy();
      expect(seen['type'], 'application/json');
    });

    test('posts JSON', () async {
      await api.setSystemProxy('clear');
      expect(seen['type'], 'application/json');
      expect(jsonDecode(seen['body'] as String), {'mode': 'clear'});
    });

    test(
      'passes manifest download metadata through the authenticated API',
      () async {
        final source = <String, Object?>{
          'file': 'Arman-VPN-Windows-x64.zip',
          'url': 'https://cdn.example/package',
          'checksums_url': 'https://cdn.example/sums',
          'signature_url': 'https://cdn.example/signature',
        };
        await api.downloadUpdate('1.2.3', source: source);
        expect(seen['token'], 'secret-token');
        expect(jsonDecode(seen['body'] as String), {
          'version': '1.2.3',
          'source': source,
        });
      },
    );

    test('turns error answers into CoreApiException', () async {
      await expectLater(
        api.test(),
        throwsA(
          isA<CoreApiException>()
              .having((e) => e.statusCode, 'status', 409)
              .having((e) => e.message, 'message', 'the proxy is not running'),
        ),
      );
    });

    test('reports a missing core as CoreUnavailable', () async {
      await server.close(force: true);
      await expectLater(api.status(), throwsA(isA<CoreUnavailable>()));
    });
  });

  group('CoreLocator', () {
    late Directory dir;

    setUp(() => dir = Directory.systemTemp.createTempSync('core_locator_'));
    tearDown(() => dir.deleteSync(recursive: true));

    test('reads the token and the dashboard address', () async {
      File('${dir.path}/local-api.token').writeAsStringSync('abc\n');
      File('${dir.path}/config.json').writeAsStringSync(
        jsonEncode({
          'dashboard': {'listen': '0.0.0.0:9191'},
        }),
      );
      final e = await CoreLocator.locate(dir.path);
      expect(e.token, 'abc');
      expect(e.baseUri.toString(), 'http://127.0.0.1:9191');
    });

    test('defaults the address without a config', () async {
      File('${dir.path}/local-api.token').writeAsStringSync('abc');
      final e = await CoreLocator.locate(dir.path);
      expect(e.baseUri.toString(), 'http://127.0.0.1:10820');
    });

    test('explains a missing token', () async {
      await expectLater(
        CoreLocator.locate(dir.path),
        throwsA(isA<CoreUnavailable>()),
      );
    });

    test('takes --data-dir from the arguments', () {
      expect(CoreLocator.dataDir(['--data-dir=C:/x/data']), 'C:/x/data');
    });

    test('keeps the data in one place for every version', () {
      String dir({
        bool portable = false,
        String os = 'windows',
        Map<String, String>? env,
      }) => CoreLocator.dataDirFor(
        args: const [],
        exeDir: r'D:\dist\Arman-VPN-1.3',
        portable: portable,
        env: env ?? {'LOCALAPPDATA': r'C:\Users\u\AppData\Local'},
        os: os,
      );
      // Windows: always beside the app.
      expect(dir(), r'D:\dist\Arman-VPN-1.3\user-data');
      expect(dir(portable: true), r'D:\dist\Arman-VPN-1.3\user-data');
      expect(
        dir(os: 'macos', env: {'HOME': '/Users/u'}),
        '/Users/u/Library/Application Support/Arman VPN',
      );
      expect(
        dir(os: 'linux', env: {'HOME': '/home/u'}),
        '/home/u/.local/share/arman-vpn',
      );
    });

    test('maps listen addresses to loopback URLs', () {
      expect(CoreLocator.listenUri('[::1]:9090').host, '::1');
      expect(
        CoreLocator.listenUri(':8080').toString(),
        'http://127.0.0.1:8080',
      );
      expect(CoreLocator.listenUri('[::]:8080').host, '127.0.0.1');
    });
  });

  test(
    'the data folder of a version before 1.0.9 moves to the new name, once',
    () {
      final sep = Platform.pathSeparator;
      for (final names in [
        ['Firefox VPN Client', 'Arman VPN'],
        ['firefox-vpn-client', 'arman-vpn'],
      ]) {
        final base = Directory.systemTemp.createTempSync('legacy');
        addTearDown(() => base.deleteSync(recursive: true));
        final old = Directory('${base.path}$sep${names[0]}')..createSync();
        File('${old.path}${sep}config.json').writeAsStringSync('{}');
        final dir = '${base.path}$sep${names[1]}';
        CoreLocator.moveLegacyDataDir(dir);
        expect(File('$dir${sep}config.json').existsSync(), isTrue);
        expect(old.existsSync(), isFalse);
        // A new folder exists: the old one stays apart.
        old.createSync();
        CoreLocator.moveLegacyDataDir(dir);
        expect(old.existsSync(), isTrue);
      }
      // user-data beside the app keeps its name.
      final base = Directory.systemTemp.createTempSync('legacy');
      addTearDown(() => base.deleteSync(recursive: true));
      Directory('${base.path}${sep}Firefox VPN Client').createSync();
      CoreLocator.moveLegacyDataDir('${base.path}${sep}user-data');
      expect(Directory('${base.path}${sep}user-data').existsSync(), isFalse);
    },
  );
}
